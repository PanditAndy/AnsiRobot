💛━━━━━━━━💚━━━━━━━━♥️
### ♥️Lovers♥️

<!--
**BadshahAk/ansi_Ro_bot** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.
<p align="center">
    <b>ᴠɪsɪᴛᴏʀs</b><br>
 -->    <img align="middle" src="https://profile-counter.glitch.me/BadshahAk/count.svg" />
</p>


💛━━━━━━━━💚━━━━━━━━♥️


<h1 align="center">
<a href="https://telegram.dog/ansi_Ro_bot">❦𝙰𝚗𝚜𝚒࿐☆​​​​​​​​​​</a>
</h1>

💛━━━━━━━━💚━━━━━━━━♥️



<p align="center">
  <img src="https://te.legra.ph/file/d5f6796456709ff9ec758.jpg">
</p>

💛━━━━━━━💚━━━━━━━━━♥️
### OWNER⚜️
</p>
<p align="center"><a href="https://t.me/Brahman_Anand"><img src="https://te.legra.ph/file/0654b1c388625ca809126.jpg" width="400"></a></p>

💛━━━━━━━💚━━━━━━━━━♥️


<p align="center">
<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>

<h3 align="center">
    ♥️𝐃𝐄𝐏𝐋𝐎𝐘 ᴏɴ ʜᴇʀᴏᴋᴜ♥️
</h3>

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/BadshahAk/ansi_Ro_bot"> <img src="https://img.shields.io/badge/💜𝗗𝗘𝗣𝗟𝗢𝗬 ᴏɴ ʜᴇʀᴏᴋᴜ💜-darkred?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
💛━━━━━━━💚━━━━━━━━━♥️
<h3 align="center">
     Special Credits 💖
</h3>

<p align="center">
<a href="https://t.me/itz_legend_coder"><img src="https://img.shields.io/badge/-Randi💯-Red.svg?style=for-the-badge&logo=Telegram"></a>
<a href="https://t.me/@AnonymousX1025"><img src="https://img.shields.io/badge/-𝝙𝗡𝗢𝗡𝗬𝗠𝗢𝗨𝗦-Green.svg?style=for-the-badge&logo=Telegram"></a>
</p>
💛━━━━━━━💚━━━━━━━━━♥️
<h3 align="center">
    ─「 ᴄʀᴇᴅɪᴛs 」─
</h3>

- <b>[ᴀɴᴏɴʏᴍᴏᴜs](https://github.com/AnonymousX1025)  ➻  [sᴏᴍᴇᴛʜɪɴɢ](https://github.com/AnonymousX1025/FallenRobot) </b>
- <b>[ᴩᴀᴜʟ ʟᴀʀsᴇɴ](https://github.com/PaulSonOfLars)  ➻  [ᴛɢ ʙᴏᴛ](https://github.com/PaulSonOfLars/tgbot) </b>
- <b>[ᴀɴɪᴍᴇ ᴋᴀɪᴢᴏᴋᴜ](https://github.com/AnimeKaizoku)  ➻  [sᴀɪᴛᴀᴍᴀ ʀᴏʙᴏᴛ](https://github.com/AnimeKaizoku/SaitamaRobot) </b>
- <b>[ʜᴀᴍᴋᴇʀ ᴄᴀᴛ](https://github.com/TheHamkerCat)  ➻  [ᴡɪʟʟɪᴀᴍ ʙᴜᴛᴄʜᴇʀ](https://github.com/TheHamkerCat/WilliamButcherBot) </b>
 
<b>ᴀɴᴅ ᴀʟʟ [ᴛʜᴇ ᴄᴏɴᴛʀɪʙᴜᴛᴏʀs](https://github.com/BadshahAk/ansi_Ro_bot/graphs/contributors) ᴡʜᴏ ʜᴇʟᴩᴇᴅ ɪɴ ᴍᴀᴋɪɴɢ   ❦𝙰𝚗𝚜𝚒࿐☆​​​​​​​​​​ ᴜsᴇғᴜʟ & ᴩᴏᴡᴇʀғᴜʟ 🖤 </b>

💛━━━━━━━💚━━━━━━━━━♥️
<h3 align="center">
      Music 🎶 Credits 💖
</h3>
<a href="https://t.me/Honey_Singh_121"><img src="https://img.shields.io/badge/-♦️SAGAR TIWARI♦️-Blue.svg?style=for-the-badge&logo=Telegram"></a>
<a href="https://t.me/TheYukki"><img src="https://img.shields.io/badge/-The Yukki-Blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>
💛━━━━━━━💚━━━━━━━━━♥️
